Question2:

1. Open 'AutomationFramework' solution in Visual Studio.

2. Add references for below from Nuget Package Manager(If not added automatically):
	a. DotNetSeleniumExtras.PageObjects
	b. DotNetSeleniumExtras.PageObjects.Core
	c. NUnit
	d. NUnit3TestAdapter
	e. Selenium.Support
	f. Selenium.WebDriver
	g. Selenium.WebDriver.ChromeDriver

3. Make sure Chrome Browser with version 91 on system

4. For executing the tests, go to 'Test Explorer' and run the below tests:
	a. Test Name:	Verify_DropDownList
	b. Test Name:	Verify_Email

5. Please refer logs generated at path: "\\AutomationFramework\AutomationFramework\TestLogs" for successful runs


